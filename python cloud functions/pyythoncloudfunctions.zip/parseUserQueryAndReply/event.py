data = {
   "oldValue":{
      
   },
   "updateMask":{
      
   },
   "value":{
      "createTime":"2021-07-15T04:39:54.514479Z",
      "fields":{
         "botReply":{
            "booleanValue":False
         },
         "device":{
            "stringValue":"desktop"
         },
         "name":{
            "stringValue":"github6 v360"
         },
         "photoUrl":{
            "stringValue":"https://lh3.googleusercontent.com/a/AATXAJwOgHVZYYMBH1lW25Kz1p_MBkMeZ3fXqh-EnrwX=s96-c"
         },
         "text":{
            "stringValue":"G H FL IF 0.18 0.45 253 2161"
         },
         "timeStamp":{
            "integerValue":"1626323994492"
         },
         "uid":{
            "stringValue":"uNHBchHOMYP581vTQ5exhfftbWW2"
         }
      },
      "name":"projects/kp-assist/databases/(default)/documents/chats/V65Xdo4EENQmDopi4GkCFiWh3oz2/messages/YMNEXVEzorGSv616KV4o",
      "updateTime":"2021-07-15T04:39:54.514479Z"
   }
}


event = {
   "event_id":"b571e561-37b3-47fb-aff0-2f5a0cd0ebb8-0",
   "timestamp":"2021-07-15T04:39:54.514479Z",
   "event_type":"providers/cloud.firestore/eventTypes/document.create",
   "resource":"projects/kp-assist/databases/(default)/documents/chats/V65Xdo4EENQmDopi4GkCFiWh3oz2/messages/YMNEXVEzorGSv616KV4o"
}